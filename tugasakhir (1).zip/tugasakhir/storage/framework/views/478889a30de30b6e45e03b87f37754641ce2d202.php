<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div style="background: rgb(12, 185, 99); margin: 0 auto;
    padding-top: 10px;
    height: 50px;
    width: 200px; 
    text-align: center; 
    border-radius: 25px; 
    box-shadow: 10px 10px 10px; 
    margin-bottom: 20px">
        <form action="/edit" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <table>
                <tr>
                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td>Id Buku:<?php echo e($a->idbuku); ?></td>
                    <td>
                        <input type="hidden" name="idbuku" value="<?php echo e($a->idbuku); ?>">
                    </td>
                    <tr>
                        <td>Judul :</td>
                        <td>
                            <input type="text" name="NamaBuku" id="Namabuku" class="form-control" value="<?php echo e($a->NamaBuku); ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>Nama Pengarang :</td>
                        <td>
                            <input type="text" name="NamaPengarang" id="NamaPengarang" class="form-control" value="<?php echo e($a->NamaPengarang); ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>Qty :</td>
                        <td>
                            <input type="number" name="qty" id="qty" min="1" max="100" class="form-control" value="<?php echo e($a->qty); ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>Jenis Buku :</td>
                        <td>
                            <select name="Kategori" id="Kategori" style="width: 200px;" class="form-select form-select-lg">
                                <option value="Keislaman">Keislaman</option>
                                <option value="Fiksi">Fiksi</option>
                                <option value="Saintek">Saintek</option>                        
                            </select>
                        </td>
                    </tr>
                </tr>
            </table>
            <image src="<?php echo e(Storage::url($b->Image)); ?>"  width="150" height="200">
            <br>
            <input type="submit" class="btn btn-danger" value="Edit">
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\projectiqbal\resources\views/update.blade.php ENDPATH**/ ?>