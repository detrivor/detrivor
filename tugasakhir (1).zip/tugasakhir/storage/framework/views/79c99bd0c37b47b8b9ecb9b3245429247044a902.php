<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript">
        $(document).ready(function(){
            $("#deskrip").click(function(){
            $("#penjelasan").slideToggle(200)
            });
        });
    </script>
    <title></title>
</head>
<body>
<table border="1" class="table table-hover">
        <tr>
            <th>ID Film</th>
            <th>Image</th>
            <th>Deskripsi</th>
            <th>Trailer</th>
            <?php if(session()->get('status')=='admin'): ?>
            <th>Action</th>
            <?php endif; ?>
        </tr>
        <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($b->Idfilm); ?></td>
            <td><image src="<?php echo e(Storage::url($b->Image)); ?>"  width="150" height="200"></td>
            <td style="max-width:600px">
                <p>Judul : <br><?php echo e($b->JudulFilm); ?></p>
                <button type="button" id="deskrip">Deskripsi</button>
                <p id="penjelasan" style="display:none;">
                Pengarang : <?php echo e($b->sutradara); ?><br>
                Genre : <?php echo e($b->Kategori); ?> <br>
                Sinopsis :<br><?php echo e($b->Sinopsis); ?>

                </p>
                </td>
            
            <td><button type="button" class="btn btn-info btn" data-bs-toggle="modal" data-bs-target="#ModalTrailer">Trailer</button></td>
            <?php if(session()->get('status')=='admin'): ?>
            <td>
                <a href="/show/<?php echo e($b->Idfilm); ?>"><button type="button" class="btn btn-success btn">Edit</button></a>
                <a href="/hapus/<?php echo e($b->Idfilm); ?>"><button type="button" class="btn btn-danger btn">Hapus</button></a>
            </td>
            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <div class="modal" id="ModalTrailer">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
            
                <?php echo e(csrf_field()); ?>

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Trailer <?php echo e($b->JudulFilm); ?></h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                <iframe width="768" height="350" src="<?php echo e($b->video); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\tugasakhir\resources\views/index.blade.php ENDPATH**/ ?>