<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<table border="1" class="table table-hover">
        <tr>
            <th>idbuku</th>
            <th>NamaBuku</th>
            <th>NamaPengarang</th>
            <th>Kategori</th>
            <th>qty</th>
            <th>Image</th>
        </tr>
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($b->idbuku); ?></td>
            <td><?php echo e($b->NamaBuku); ?></td>
            <td><?php echo e($b->NamaPengarang); ?></td>
            <td><?php echo e($b->Kategori); ?></td>
            <td><?php echo e($b->qty); ?></td>
            <td><image src="<?php echo e(Storage::url($b->Image)); ?>"  width="150" height="200"></td>
            <td>
                <a href="/show/<?php echo e($b->idbuku); ?>"><button type="button" class="btn btn-success btn">Edit</button></a>
                <a href="/hapus/<?php echo e($b->idbuku); ?>"><button type="button" class="btn btn-danger btn">Hapus</button></a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\projectiqbal\resources\views/index.blade.php ENDPATH**/ ?>